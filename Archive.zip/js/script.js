const map = L.map('map').setView([32.3394, -6.3608], 15); // Beni Mellal

const googleHybrid = L.tileLayer('http://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}', {
    maxZoom: 20,
    subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
}).addTo(map);

const markers = L.markerClusterGroup({
    disableClusteringAtZoom: 20,
    spiderfyOnMaxZoom: true,
    showCoverageOnHover: true,
    zoomToBoundsOnClick: true
});
map.addLayer(markers);

const addMarkerBtn = document.getElementById('addMarkerBtn');
const userNameInput = document.getElementById('userName');
const latInput = document.getElementById('latInput');
const lngInput = document.getElementById('lngInput');

function createPopupContent(userName, date, lat, lng, marker) {
    const container = document.createElement('div');
    container.className = 'popup-content';

    const infoDiv = document.createElement('div');
    infoDiv.innerHTML = `
        <strong>Added by:</strong> ${userName}<br>
        <strong>Date:</strong> ${date}<br>
        <strong>Coordinates:</strong><br>
        Latitude: ${lat}<br>
        Longitude: ${lng}
    `;
    container.appendChild(infoDiv);

    const actionsDiv = document.createElement('div');
    actionsDiv.className = 'popup-actions';

    const editBtn = document.createElement('button');
    editBtn.className = 'edit-button';
    editBtn.innerHTML = '✏️';
    editBtn.onclick = () => showEditForm(infoDiv, userName, date, lat, lng, marker);

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'delete-button';
    deleteBtn.innerHTML = '🗑️';
    deleteBtn.onclick = () => {
        markers.removeLayer(marker);
        removeMarkerFromStorage(lat, lng); // new
    };

    actionsDiv.appendChild(editBtn);
    actionsDiv.appendChild(deleteBtn);
    container.appendChild(actionsDiv);

    return container;
}

function showEditForm(infoDiv, userName, date, lat, lng, marker) {
    const form = document.createElement('div');
    form.className = 'edit-form';
    form.innerHTML = `
        <input type="text" id="editName" value="${userName}" placeholder="Name">
        <input type="number" id="editLat" value="${lat}" step="any" placeholder="Latitude">
        <input type="number" id="editLng" value="${lng}" step="any" placeholder="Longitude">
        <button class="save-button">💾 Save</button>
    `;

    const saveBtn = form.querySelector('.save-button');
    saveBtn.onclick = () => {
        const newName = form.querySelector('#editName').value.trim() || userName;
        const newLat = parseFloat(form.querySelector('#editLat').value);
        const newLng = parseFloat(form.querySelector('#editLng').value);

        if (!isNaN(newLat) && !isNaN(newLng)) {
            marker.setLatLng([newLat, newLng]);
            const newPopup = createPopupContent(newName, date, newLat.toFixed(6), newLng.toFixed(6), marker);
            marker.setPopupContent(newPopup);
        }
    };

    infoDiv.parentElement.insertBefore(form, infoDiv.nextSibling);
}

function saveMarkerToStorage(markerData) {
    let stored = JSON.parse(localStorage.getItem('savedMarkers')) || [];
    stored.push(markerData);
    localStorage.setItem('savedMarkers', JSON.stringify(stored));
}

function removeMarkerFromStorage(lat, lng) {
    let stored = JSON.parse(localStorage.getItem('savedMarkers')) || [];
    stored = stored.filter(m => m.lat !== lat || m.lng !== lng);
    localStorage.setItem('savedMarkers', JSON.stringify(stored));
}

function addMarker(userName, lat, lng, date, save = true) {
    lat = parseFloat(lat.toFixed(6));
    lng = parseFloat(lng.toFixed(6));

    const marker = L.marker([lat, lng], { draggable: true });
    markers.addLayer(marker);

    const popupContent = createPopupContent(userName, date, lat, lng, marker);
    marker.bindPopup(popupContent).openPopup();

    marker.on('dragend', function () {
        const newPos = marker.getLatLng();
        const newLat = parseFloat(newPos.lat.toFixed(6));
        const newLng = parseFloat(newPos.lng.toFixed(6));
        const newPopup = createPopupContent(userName, date, newLat, newLng, marker);
        marker.setPopupContent(newPopup);
    });

    if (save) {
        saveMarkerToStorage({ userName, lat, lng, date });
    }

    latInput.value = '';
    lngInput.value = '';
}

addMarkerBtn.addEventListener('click', function () {
    const userName = userNameInput.value.trim() || 'Noaman';
    const currentDate = new Date().toLocaleString();
    let lat, lng;

    if (latInput.value && lngInput.value) {
        lat = parseFloat(latInput.value);
        lng = parseFloat(lngInput.value);
    } else {
        const center = map.getCenter();
        lat = center.lat;
        lng = center.lng;
    }

    addMarker(userName, lat, lng, currentDate);
});

map.on('dblclick', function (e) {
    const userName = userNameInput.value.trim() || 'Noaman';
    const currentDate = new Date().toLocaleString();
    const lat = parseFloat(e.latlng.lat.toFixed(6));
    const lng = parseFloat(e.latlng.lng.toFixed(6));

    addMarker(userName, lat, lng, currentDate);
});

function loadMarkersFromStorage() {
    const stored = JSON.parse(localStorage.getItem('savedMarkers')) || [];
    stored.forEach(markerData => {
        addMarker(markerData.userName, markerData.lat, markerData.lng, markerData.date, false);
    });
}

loadMarkersFromStorage(); // Load on startup
